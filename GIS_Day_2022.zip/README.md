# GIS Day 2022
To install, just run `gis_day_install.py` or download the project and extract into `C:\Student\GISDay_2022`
<br>
This project was compiled in ArcGIS Pro 2.8 so ealier version may give you a warning of incompatibility.  Should work, however. 